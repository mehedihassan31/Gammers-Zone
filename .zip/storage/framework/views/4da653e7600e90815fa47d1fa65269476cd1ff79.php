

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-3 p-2">
                <div class="card">
                    <div class="card-body text-center">
                        <h3 class="count-card-title text-center"><?php echo e($totalproduct); ?></h3>
                        <h3 class="count-card-title">Total Products</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 p-2">
                <div class="card">
                    <div class="card-body text-center">
                        <h3 class="count-card-title text-center"><?php echo e($totalorder); ?></h3>
                        <h3 class="count-card-title">Total Order</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 p-2">
                <div class="card">
                    <div class="card-body text-center">
                        <h3 class="count-card-title text-center"><?php echo e($totalusers); ?></h3>
                        <h3 class="count-card-title">Total Users</h3>
                    </div>
                </div>
            </div>

            

        </div>
    
    
    </div>


</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Gammers-Zone\resources\views/admin/home.blade.php ENDPATH**/ ?>